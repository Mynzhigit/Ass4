// AdminController.js
// Import necessary modules and models
const PortfolioItem = require('../models/PortfolioItem'); // Import the PortfolioItem model
const fs = require('fs'); // File system module for file operations
const path = require('path'); // Path module for working with file paths

// Define AdminController object to handle administrative operations
const AdminController = {
    // Method to render the admin dashboard
    getAdminDashboard: async (req, res) => {
        try {
            // Retrieve all portfolio items from the database
            const portfolioItems = await PortfolioItem.find();
            // Render the admin dashboard view with portfolio items data
            res.render('admin', { portfolioItems });
        } catch (error) {
            console.error(error);
            res.status(500).send('Internal Server Error'); // Handle server error
        }
    },

    // Method to render the add portfolio item form
    getAddPortfolioItem: (req, res) => {
        res.render('add'); // Render the add portfolio item form view
    },

    // Method to handle adding a new portfolio item
    postAddPortfolioItem: async (req, res) => {
        try {
            // Extract name, description, and images from request body and files
            const { name, description } = req.body;
            const images = req.files.map(file => file.path);

            // Create a new PortfolioItem instance
            const newItem = new PortfolioItem({
                name,
                description,
                images
            });

            // Save the new portfolio item to the database
            await newItem.save();
            res.redirect('/admin'); // Redirect to the admin dashboard
        } catch (error) {
            console.error(error);
            res.status(500).send('Internal Server Error'); // Handle server error
        }
    },

    // Method to handle deleting a portfolio item
    deletePortfolioItem: async (req, res) => {
        try {
            const id = req.params.id; // Extract the portfolio item ID from the request parameters
            const item = await PortfolioItem.findById(id); // Find the portfolio item by ID

            // Loop through each image associated with the portfolio item and delete it from the file system
            for (const imagePath of item.images) {
                const fullPath = path.join(__dirname, '..', imagePath); // Construct full file path
                if (fs.existsSync(fullPath)) {
                    fs.unlinkSync(fullPath); // Delete the file if it exists
                } else {
                    console.log(`File not found: ${fullPath}`);
                }
            }

            // Delete the portfolio item from the database
            await PortfolioItem.findByIdAndDelete(id);
            res.redirect('/admin'); // Redirect to the admin dashboard
        } catch (error) {
            console.error(error);
            res.status(500).send('Internal Server Error'); // Handle server error
        }
    },

    // Method to render the edit portfolio item form
    getEditPortfolioItem: async (req, res) => {
        try {
            const id = req.params.id; // Extract the portfolio item ID from the request parameters
            const item = await PortfolioItem.findById(id); // Find the portfolio item by ID
            res.render('edit', { item }); // Render the edit portfolio item form view with item data
        } catch (error) {
            console.error(error);
            res.status(500).send('Internal Server Error'); // Handle server error
        }
    },

    // Method to handle updating a portfolio item
    postEditPortfolioItem: async (req, res) => {
        try {
            const id = req.params.id; // Extract the portfolio item ID from the request parameters
            const { name, description } = req.body; // Extract name and description from request body
            const images = req.files.map(file => file.path); // Extract image paths from uploaded files

            // Update the portfolio item in the database
            await PortfolioItem.findByIdAndUpdate(id, {
                name,
                description,
                images,
                updatedAt: Date.now() // Update the 'updatedAt' field with the current date
            });

            res.redirect('/admin'); // Redirect to the admin dashboard
        } catch (error) {
            console.error(error);
            res.status(500).send('Internal Server Error'); // Handle server error
        }
    }
};

module.exports = AdminController; // Export the AdminController object for use in other modules
