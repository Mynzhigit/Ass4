// Define mongoose module for MongoDB interactions
const mongoose = require('mongoose');
// Define Schema object from mongoose
const Schema = mongoose.Schema;

// Define portfolio item schema with specified fields and types
const portfolioItemSchema = new Schema({
    name: String, // Name of the portfolio item
    description: String, // Description of the portfolio item
    images: [String], // Array of image paths associated with the portfolio item
    createdAt: { type: Date, default: Date.now }, // Date of creation, defaults to current date
    updatedAt: { type: Date, default: Date.now } // Date of last update, defaults to current date
});

// Create PortfolioItem model using the portfolioItemSchema
const PortfolioItem = mongoose.model('PortfolioItem', portfolioItemSchema);

// Export the PortfolioItem model for use in other modules
module.exports = PortfolioItem;
