// Import necessary modules
const express = require('express'); // Import Express framework
const session = require('express-session'); // Middleware for session management
const path = require('path'); // Module for working with file paths
const mongoose = require('mongoose'); // MongoDB object modeling tool

// Set the default PORT to 3000 or use the environment variable PORT if available
const PORT = process.env.PORT || 3000;

// Create an instance of the Express application
const app = express();

// Middleware setup
app.use(express.urlencoded({ extended: true })); // Middleware to parse URL-encoded request bodies
app.use(express.json()); // Middleware to parse JSON request bodies
app.use(express.static(path.join(__dirname, 'public'))); // Middleware to serve static files from the 'public' directory
app.use(session({
    secret: 'secret', // Secret used to sign the session ID cookie
    resave: true, // Forces the session to be saved back to the session store
    saveUninitialized: true // Forces a session that is "uninitialized" to be saved to the store
}));

// Set views directory and view engine
app.set('views', path.join(__dirname, 'views')); // Set the directory for views
app.set('view engine', 'ejs'); // Set EJS as the view engine

// Connect to MongoDB database named 'portfolio'
mongoose.connect('mongodb://localhost:27017/portfolio', {
    useNewUrlParser: true, // Use new URL parser
    useUnifiedTopology: true, // Use new Server Discover and Monitoring engine
});

// Export the Express application instance and the PORT constant
module.exports = { app, PORT };
