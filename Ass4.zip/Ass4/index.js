
// Import the Express application instance (app) and the PORT constant from the 'server.js' file
const { app, PORT } = require('./server');

// Import the routes defined in the 'routes.js' file
const routes = require('./routes');

// Mount the routes onto the Express application
app.use(routes);

// Start the Express server, listening on the specified PORT
app.listen(PORT, () => {
    // Log a message to the console indicating that the server is running and on which port
    console.log(`Server is running on port ${PORT}`);
});
