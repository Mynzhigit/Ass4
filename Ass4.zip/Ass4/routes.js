// Import the Express module
const express = require('express');
// Create an instance of the Express application
const app = express();

// Import user routes
const userRoutes = require('./routes/userRoutes');
// Import admin routes
const adminRoutes = require('./routes/adminRoutes');
// Import weather controller
const weatherController = require('./controllers/weatherController');

// Mount user routes at the root path
app.use('/', userRoutes);
// Mount admin routes under the '/admin' path
app.use('/admin', adminRoutes);
// Define a route to handle weather API requests
app.get('/api/weather', weatherController.getWeather);

// Export the Express application instance
module.exports = app;
